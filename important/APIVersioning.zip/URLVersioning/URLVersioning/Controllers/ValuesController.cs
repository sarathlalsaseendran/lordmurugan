﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace URLVersioning.Controllers
{
    [ApiVersion("1.0")]
    [Route("v{v:apiVersion}/values")]
    [ApiController]
    public class Values1Controller : ControllerBase
    {
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1 - V1", "value2 - V1" };
        }
    }

    [ApiVersion("2.0")]
    [Route("v{v:apiVersion}/values")]
    [ApiController]
    public class Values2Controller : ControllerBase
    {
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1 - V2", "value2 - V2" };
        }
    }
}
