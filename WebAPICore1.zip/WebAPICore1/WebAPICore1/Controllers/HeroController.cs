﻿namespace WebAPICore1.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using WebAPICore1.Models;

    [Route("api/Hero")]
    public class HeroController : Controller
    {
        private readonly IDocumentDBRepository<Hero> Respository;
        public HeroController(IDocumentDBRepository<Hero> Respository) => this.Respository = Respository;

        [HttpGet]
        public async Task<IEnumerable<Hero>> GetAsync()
        {

            IEnumerable<Hero> value = await Respository.GetItemsAsync();
            return value;
        }

        [HttpPost]
        public async Task<Hero> CreateAsync([FromBody] Hero hero)
        {
            if (ModelState.IsValid)
            {
                await Respository.CreateItemAsync(hero);
                return hero;
            }
            return null;
        }

        [HttpDelete("{uid}")]
        public async Task<string> DeleteAsync(string uid)
        {
            try
            {
                Hero item = await Respository.GetSingleItemAsync(d => d.UId == uid);
                if (item == null)
                {
                    return "Failed";
                }
                await Respository.DeleteItemAsync(item.Id);
                return "Success";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        [HttpPut("{uid}")]
        public async Task<Hero> EditAsync(string uid, [FromBody] Hero hero)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Hero item = await Respository.GetSingleItemAsync(d => d.UId == uid);
                    if (item == null)
                    {
                        return null;
                    }
                    hero.Id = item.Id;
                    await Respository.UpdateItemAsync(item.Id, hero);
                    return hero;
                }
                return null; ;
            }
            catch (Exception ex)
            {
                return null;
            }
           
        }
    }
}
