﻿namespace WebAPICore1.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using WebAPICore1.Models;

    [Route("api/Item")]
    public class ItemController : Controller
    {
        private readonly IDocumentDBRepository<Item> Respository;
        public ItemController(IDocumentDBRepository<Item> Respository) => this.Respository = Respository;

        [HttpGet]
        public async Task<IEnumerable<Item>> GetAsync()
        {

            IEnumerable<Item> value = await Respository.GetItemsAsync(d => !d.Completed);
            return value;
        }

        [HttpPost]
        public async Task<HttpResponseMessage> CreateAsync([Bind("Id,Name,Description,Completed")]Item item)
        {
            if (ModelState.IsValid)
            {
                await Respository.CreateItemAsync(item);
                return new HttpResponseMessage(HttpStatusCode.Created);
            }
            return new HttpResponseMessage(HttpStatusCode.ExpectationFailed);
        }
    }
}
