export class Hero {
  uid: string;
  name: string;
  saying: string;
}
