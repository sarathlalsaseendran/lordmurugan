import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Hero } from './hero';

const api = 'http://localhost:1500/api';

@Injectable()
export class HeroService {
  constructor(private http: HttpClient) { }

  getHeroes() {
    return this.http.get<Array<Hero>>(`${api}/hero`);
  }

  deleteHero(hero: Hero) {
    return this.http.delete<string>(`${api}/hero/${hero.uid}`);
  }

  addHero(hero: Hero) {
    return this.http.post<Hero>(`${api}/hero/`, hero);
  }

  updateHero(hero: Hero) {
    return this.http.put<Hero>(`${api}/hero/${hero.uid}`, hero);
  }
}
