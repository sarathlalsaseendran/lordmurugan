const mongoose = require('mongoose');
/**
 * Set to Node.js native promises
 * Per http://mongoosejs.com/docs/promises.html
 */
mongoose.Promise = global.Promise;

const env = require('./env/environment');

// eslint-disable-next-line max-len
const mongoUri = `mongodb://sarathcosmosmongo1:d9CcpzFcfWnsBm9u8leoOyoTHJ6ABabSp4j0DsWe1X2boxvlD4OFkrddfmWft5gmlWYOOZ9OzzPKsChPZRgFKQ==@sarathcosmosmongo1.documents.azure.com:10255/?ssl=true&replicaSet=globaldb`;

function connect() {
  mongoose.set('debug', true);
  return mongoose.connect(
    mongoUri,
    {
      useMongoClient: true
    }
  );
}

module.exports = {
  connect,
  mongoose
};
