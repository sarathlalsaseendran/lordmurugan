module.exports = {
  accountName: 'sarathcosmosmongo1',
  databaseName: 'admin',
  key: 'd9CcpzFcfWnsBm9u8leoOyoTHJ6ABabSp4j0DsWe1X2boxvlD4OFkrddfmWft5gmlWYOOZ9OzzPKsChPZRgFKQ%3D%3D',
  port: 10255
};
