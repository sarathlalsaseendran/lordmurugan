import { Models } from './models';

describe('Models', () => {
  it('should create an instance', () => {
    expect(new Models()).toBeTruthy();
  });
});
